'''
Created on 18-Sep-2019

@author: mayur.shahapure
'''
from datetime import datetime
from elasticsearch import Elasticsearch
import json
from _datetime import datetime
es = Elasticsearch()
CTO_INDEX_NAME = 'cto-meta-map'
#Sample Mapping format
indexDoc = {
    "mappings": {
        "food": {
            "dynamic_templates": [
              {
                "doubles_as_strings": {
                  "match": "foodConfidence*",
                  "match_mapping_type": "string",
                  "mapping": {
                    "type": "double"
                  }
                }
              }
            ],
            "properties": {
              "color": {
                "type": "text",
                "fields": {
                  "raw": {
                    "type": "keyword"
                  }
                }
              },
              "cookingsession": {
                "type": "text",
                "fields": {
                  "raw": {
                    "type": "keyword"
                  }
                }
              },
              "createdDate": {
                "type": "date",
                "format": "date_optional_time"
              },
              "geo_location": {
                "type": "geo_point"
              },             
              "timestamp": {
                "type": "date",
                "format": "date_optional_time"
              }
            }
      }
    },
    "settings" : {
        "number_of_shards": 1,
        "number_of_replicas": 0
    }
}

# Create index
res = es.indices.exists(index=CTO_INDEX_NAME)
print("index {} exists = {}".format(CTO_INDEX_NAME, res))
if res is False:
    es.indices.create(index=CTO_INDEX_NAME, body=indexDoc,include_type_name=True)

# Add data in index

#To add data create body as per mapping format
searchBody = {
}
searchBody['color'] = 'red'
searchBody['cookingsession']='Thepla'
searchBody['createdDate']=datetime.now()
searchBody['geo_location']={
        'lat':23.0225,
        'lon':72.5714
    }

dt=datetime.now()
print(datetime.strptime('20190918150908', '%Y%m%d%H%M%S').isoformat())
searchBody['timestamp']= datetime.strptime('20190918150908', '%Y%m%d%H%M%S').isoformat()
#datetime.strptime("20190918150908", '%Y%m%d%H%M%S')
 
# Query to add data in index           
retval = es.index(index=CTO_INDEX_NAME, doc_type='food', body=searchBody)
print('retval=', retval)


#Search index and get all data
res1 = es.search(index=CTO_INDEX_NAME, body={"query": {"match_all": {}}})
print("res1 = ",res1)